function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  noFill();
   strokeWeight (5);
  point (25,40,55);
  ellipse (100,120,90,90);
  rect (200,200,100,150);
  rect (250,250,20,100);
  strokeCap(SQUARE)
  line(400,0,20,350);
  strokeCap(ROUND)
  line(360,0,10,330);
  strokeWeight(10);
  fill(50);
  ellipse(350,200,60,60);
  rect(220,200,20,100);
  
}