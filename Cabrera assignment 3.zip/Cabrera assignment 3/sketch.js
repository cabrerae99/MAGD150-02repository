// intialize variables
let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 0;


function setup() {
  createCanvas(500,500);
  angleMode(RADIANS);
  // intial stroke weight
  strokeWeight(4);
  stroke (0,100);
  
  // frame rate initial value
  let fr = 30;
  frameRate (fr);
}

function draw() {
  background(220);
  // math function frame rate
  let fr = sqrt (900);
  frameRate(fr);
  
  print(fr);
  
  let mx = mouseX;
  let my = mouseY;
  let px = pmouseX;
  let py = pmouseY; 

  
  
  var weight = dist(mx, my, px, py);
  colorMode (RGB, 200,100,255,1);
   strokeWeight(weight);
  
  let d = int(dist(50, 50, pmouseX, pmouseY));

  push();
  translate((mouseX + mouseY) / 2, (pmouseX + pmouseY) / 2);
  text(nfc(d, 1), 0, 5);
  pop();
  
  stroke(200,80,75,1);
  strokeWeight(30);
  line(mx,my,px,py);
  
  
}