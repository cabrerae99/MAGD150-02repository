function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(220);
  noFill();

  colorMode(RGB, 255, 255, 255, 1);
  
  fill(130,16,236);
  
  strokeWeight(4);
  
  triangle(200,100,200,150,120,50);
  
  ellipse(500,450,100,180);
  function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(220);
  noFill();

  colorMode(RGB, 255, 255, 255, 1);
  
  fill(130,16,236);
  
  strokeWeight(4);
  
  triangle(200,100,200,150,120,50);
  
  ellipse(500,450,100,180);
  
  fill(10,40,300);
  
  arc(300,175,200,200,0,radians(90));
  
 stroke(20,100,0,20);
  
 quad(30,100,60,100,100,150,30,150);

 fill(20,150,0,60);
  
  beginShape();
  
  vertex(30,400);
  
  vertex(60,400);
  
  vertex(30,200);
  
  vertex(60,200);
  
  endShape(CLOSE);
  
  stroke(150,200,0,85);
  
  noFill();
  
  beginShape(TRIANGLE_STRIP);
  
  vertex(100, 175);
  
  vertex(140, 120);
  
  vertex(150, 175);
  
  vertex(160, 120);
  
  vertex(170, 175);
  
  vertex(180, 120);
  
  vertex(190, 175);
  
  endShape();
  
  
}